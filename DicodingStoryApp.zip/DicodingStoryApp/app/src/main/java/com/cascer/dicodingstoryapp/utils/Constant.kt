package com.cascer.dicodingstoryapp.utils

object Constant {
    const val APP_PREFERENCES = "APP_PREFERENCES"
}