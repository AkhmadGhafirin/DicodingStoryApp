package com.cascer.dicodingstoryapp.data.model

data class LoginRequest(
    val email: String,
    val password: String
)